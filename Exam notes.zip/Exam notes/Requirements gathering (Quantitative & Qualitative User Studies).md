Research with Human Participants involves conducting studies or experiments that involve living human beings, as well as human remains, embryos, foetuses, tissues, bodily fluids, and data records. Potential ethical issues may arise in such research, particularly in cases where the subject matter is controversial, sensitive, embarrassing, or upsetting. Ethical considerations may also be relevant when dealing with researchers who have conflicts of interest, as well as when working with children or young people under 18, vulnerable individuals (such as the elderly or those with health issues), and participants who may not understand the language in which the research is conducted. It is important to carefully consider and address these ethical issues in order to conduct research with human participants responsibly and ethically.

**What requirements elicitation / discovery is**:
	This process is sometimes referred to as requirements elicitation or requirements discovery. It involves technical staff collaborating with customers to understand the application domain, the services the system should offer, and the operational limitations of the system. This collaboration may include end-users, managers, maintenance engineers, domain experts, trade unions, and other relevant parties, collectively known as stakeholders.
	**Problems of requirements analysis**:
		This statement is explaining the challenges and complexities that come with gathering and understanding the requirements of stakeholders in a project or system development process. 
		1. Stakeholders may not always have a clear understanding of what they want or need, making it difficult to gather accurate requirements.
		2.  Stakeholders may express their requirements using their own terminology or language, which can lead to misunderstandings or misinterpretations.
		3. Different stakeholders may have conflicting requirements or priorities, making it challenging to reconcile and prioritize them.
		4. Organizational and political factors can influence the system requirements, potentially leading to biased or skewed requirements.
		5. The requirements can change throughout the analysis process, as new stakeholders may emerge or the business environment may evolve, requiring constant adaptation and flexibility in gathering and managing requirements.
	Software engineers collaborate with various individuals involved in the development of a system to gather information about the specific area of application, the services the system needs to offer, the desired performance of the system, hardware limitations, and other related systems. The stages of this process include discovering the requirements, organizing and categorizing them, prioritizing and negotiating them, and finally specifying the requirements in detail.
	Requirements discovery is the process of collecting information about the necessary and current systems and extracting the user and system requirements from this information. This process involves engaging with various stakeholders, including managers and external regulators, to ensure that all perspectives are considered. Systems typically have multiple stakeholders with varying needs and requirements that must be taken into account during the discovery process.

**About the issues to consider when using quantitative and qualitative methods for requirements gathering**:
	Common issues with questionnaires include:
	- Using a questionnaire when it is not necessary
	- People being hesitant to use interviews or observations
	- Including too many questions in the questionnaire
	- Using language that is not easily understood by the participants
	- Assuming that participants will be interested in the project
	- Failing to ask for feedback on the questionnaire
	- Not conducting a thorough review of existing literature or market research
	- Neglecting to brainstorm ideas for the questionnaire
	- Failing to pilot test the questionnaire before using it.


**An example for quantitative and qualitative method each**:
	**==Quantitative==** user studies involve capturing a quick snapshot of a situation or phenomenon, providing limited details on behavior, attitude, and motivation. These studies focus on describing data and characteristics of the population or phenomenon being studied.
	**==Qualitative==** user studies are important because they help researchers uncover new insights, gain a deeper understanding of user experiences or situations, and generate new ideas and hypotheses. By conducting qualitative research, researchers can gather rich and detailed data that can provide valuable information for improving products or services.
	**==Quantitative==** user studies involve techniques that are useful for reaching a large number of people, determining the majority opinion on certain topics, and comparing how different stakeholders respond to the same question. However, these studies are not effective for truly understanding and gaining insight into the system being studied. They may provide statistical data and trends, but they often lack the depth and context needed to fully comprehend the user experience or behavior.
	**==Qualitative==** user studies refer to research methods that focus on understanding the experiences, behaviors, and attitudes of users in a detailed and in-depth manner. These studies often involve techniques such as interviews, observations, and open-ended surveys to gather rich and nuanced insights into how users interact with a product, service, or system. The goal of qualitative user studies is to uncover the underlying motivations, preferences, and challenges that users face, which can then inform the design and development of user-centered solutions.
	**==Qualitative==** user studies involve collecting data through in-depth interviews, focus groups, and observations. In-depth interviews involve one-on-one discussions with participants to gather detailed information about their experiences, opinions, and behaviors. Focus groups bring together a small group of participants to discuss a specific topic or product, allowing researchers to observe group dynamics and gather insights from group interactions. Observations involve directly observing participants in their natural environment to understand how they interact with a product or service. These methods help researchers gain a deeper understanding of user needs, preferences, and behaviors.
	Fundamentals: Defining Goal(s)
	In order to effectively communicate with a stakeholder, it is important to have a clear goal or goals in mind. These goals help guide the conversation and determine what information you are seeking to gather. By defining your goals, you can frame your questions, keep the discussion focused, and identify the main topics that you will be discussing with the stakeholder. Having a clear goal in mind ensures that your communication is purposeful and productive.
	Goal focussed questions: For each topic, consider all the possible questions you could ask or the ideas you have. This will help you expand on what you want to know. Then, use this information to choose good questions. Your goal is to obtain thorough and comprehensive coverage of the topic through your questions. Your aim is to understand as much as possible about the topic.
	When it comes to using different methods, the most important skill is asking questions and following up with more questions. Simply asking one question is usually not enough - it's important to ask "why" to understand the reasons behind the answers. The goal is not just to find out what happened, but to understand the reasons, methods, timing, and location behind it.
	Open ended questions:
	![[Pasted image 20240423225514.png]]
	
**How such methods can be used within the context of your group project**
	

**Notes**:

Stakeholders are individuals or groups who have an interest or concern in a particular organization, project, or issue. They can include employees, customers, investors, suppliers, government agencies, local communities, and others who may be affected by the actions of the organization. Identifying and considering the needs and perspectives of stakeholders is important for making decisions that take into account the interests of all parties involved.

A survey is a method of collecting data from individuals by asking them a well-defined and well-written set of questions. This is usually done to gather information about their experiences and opinions. Surveys are typically conducted with a representative sample of participants, often using questionnaires as a means of gathering the necessary information.

Positives of using surveys:
1. Surveys provide a quick and efficient way to gather information from a large number of people.
2. Surveys can help in collecting data on a wide range of topics and issues.
3. Surveys allow for anonymity, which can encourage respondents to provide honest and candid feedback.
4. Surveys can be used to measure and track changes over time.

Negatives of using surveys:
1. Surveys may suffer from response bias, where respondents may provide inaccurate or dishonest answers.
2. Surveys can be time-consuming and costly to design, distribute, and analyze.
3. Surveys may not capture the full complexity of certain issues or topics.
4. Surveys may not reach certain populations or demographics, leading to a lack of diversity in responses.

  
Question design:
- Well-written
- Non-biased
- Non-leading
- Mix of open and closed,subjective and objective questions

**How we should design a questionnaire**:
When designing questionnaires, we should consider several factors such as the purpose of the survey, the target audience, the type of information we want to gather, and the format of the questions. It is important to use clear and concise language, avoid leading or biased questions, and ensure that the questions are relevant and easy to understand for the respondents. Additionally, we should consider the order and structure of the questions, as well as the response options provided. Testing the questionnaire with a small sample group can also help identify any potential issues or improvements before distributing it to a larger audience.

Guidelines for questionnaire design
1. Questionnaire purpose:
		This passage is discussing the purpose and considerations when creating a questionnaire for a survey. It emphasizes that understanding the purpose of the survey should come before writing the questions. It suggests considering current issues, describing characteristics or behaviors, and evaluating if the questionnaire is suitable for the study's context. In essence, it highlights the importance of thoughtful planning and alignment with the study's objectives before designing the questionnaire.
2. Respondent selection
		"Respondent selection refers to the process of determining who will be completing the questionnaire. This involves identifying the specific individuals or groups that the survey is targeting, and ensuring that they are the appropriate people to provide the necessary information."
		1. **Potential pitfalls:**
    
    - **Failing memory of respondents:** Respondents may have trouble recalling specific information accurately.
    - **Effect of fatigue, feeling bored, time pressure:** Respondents might get tired, lose interest, or feel rushed, impacting the quality of their responses.
    - **Socially desirable replies:** Respondents may provide answers that they think are socially acceptable or favorable, rather than being completely honest.
    - **Respondent does not want to appear stupid:** Some respondents may avoid giving certain answers to avoid looking unintelligent.
    - **“Please the researcher” effect:** Respondents might alter their responses to please the researcher, leading to biased or inaccurate information.
    These potential pitfalls highlight the importance of careful respondent selection and questionnaire design to ensure reliable and valid data collection.


3. Question content
		This is asking what specific information is needed by the person asking the question or by someone else in order to understand or address a certain issue or topic. It is prompting the individual to consider what specific details or data are necessary to answer their question or make an informed decision.
4. Question wording
		This means that when asking questions, it is important to use clear and simple language that is directly related to the topic being discussed. The questions should be concise but not overly short, and should avoid using negative or emotional language. It is also important to avoid bias or leading questions that suggest a particular answer, as well as questions that combine multiple ideas in one. The goal is to ask questions that are fair and objective in order to gather accurate information.
5. Question format
		Close-ended: A closed-ended question format is one that limits the possible responses to a specific set of options. These questions typically require a simple yes or no answer or choose from a list of predefined options. This format is used to gather specific information and can be helpful for collecting quantitative data.
		![[Closeendedquestion.png]]
		Scale: This means that the question is asking for information on a scale or rating system. The respondent is expected to provide a response that falls within a specific range or level.
		![[Pasted image 20240423224504.png]]
		
6. Question sequence
		This explanation is outlining the ideal order in which to ask questions during a self-administered survey or an interview. For a self-administered survey, it is recommended to start with interesting questions to engage the respondent, followed by less interesting questions in the middle, and saving the most personal information for the end. 
		In an interview setting, it is suggested to begin with the least threatening questions to make the interviewee feel comfortable, then move on to more personal questions in the middle, and end with less sensitive topics. This sequence helps to gradually build rapport and trust with the respondent, making them more likely to answer the more personal or sensitive questions towards the middle or end of the survey or interview.
		
7. Questionnaire length: Please make the questionnaire short and straightforward.
8. Questionnaire layout
		Questionnaire layout refers to the design and arrangement of a questionnaire, including the organization of questions, response options, and overall structure. It involves determining the order of questions, the use of headings and subheadings, the formatting of text, and the placement of visual elements such as images or graphics. A well-designed questionnaire layout can help improve respondent understanding, engagement, and overall survey completion rates.
9. Piloting the questionnaire
		"Piloting the questionnaire" refers to the process of testing a survey or questionnaire on a small group of participants before using it on a larger scale. This helps to identify any potential issues with the questions, format, or instructions, and allows for adjustments to be made to ensure the survey is clear, relevant, and effective.