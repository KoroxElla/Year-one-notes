In order for IT projects to be successful, it is crucial to have a deep understanding of the specific field or industry in which the software will be used. This includes knowing exactly what the software needs to accomplish, as well as what it should avoid doing, in order to meet
- apply quantitative and qualitative elicitation techniques to gather software requirements
- write high quality requirements to describe a software project
- create sketches and prototypes to materialise and test requirements
- create models using Unified Modeling Language (UML) to describe a software system
- demonstrate a knowledge of security and data protection issues in storage and usage of data
- describe the role of professional bodies in the IT industry
- work collaboratively on a group project, supported by a source control system (GIT)

The key things in Requirements Engineering is:
Discovering: people's needs that software can solve
Details: exactly what the software will do
Describing: it in ways that everyone can understand

The developing software and requirement process are as follows:
[[download1]]![[download1.png]]

[[download2]]![[download2.png]]

These are the table of contents for this module:
1. [[What are Requirements]]
2. [[Requirements gathering (Quantitative & Qualitative User Studies)]]
3. [[Functional Requirements]]
4. [[Non-functional Requirements]]
5. [[Overview of UML / Use Case diagrams & descriptions]]
6. [[Introduction to version control with git]]
7. [[Branching, Merging and resolving merge conflicts with git]]
8. [[UML Class Diagram]]
9. [[Class Modelling]]
10. [[Sketching and Lo-fi prototyping]]
11. [[Software laws and Professionalism]]

